import React from 'react';

export const HeroSection: React.FC = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=1600')"
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
            Dekouvri
            <span className="block bg-gradient-to-r from-rose-400 to-amber-400 bg-clip-text text-transparent">
              Pafen Liks
            </span>
          </h1>
          <p className="text-xl text-rose-100 mb-8 leading-relaxed">
            Koleksyon eksklusif pafen prensipal ki fèt ak sous ki pi kalite yo ak artisan ekspè.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="bg-gradient-to-r from-rose-600 to-rose-700 text-white px-8 py-4 rounded-full font-semibold hover:from-rose-700 hover:to-rose-800 transition-all transform hover:scale-105 shadow-lg">
              Eksplore Koleksyon
            </button>
            <button className="bg-white/20 backdrop-blur-sm text-white border-2 border-white/30 px-8 py-4 rounded-full font-semibold hover:bg-white/30 transition-all">
              Gade Videyo
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};