import React from 'react';
import { Heart, Star } from 'lucide-react';

interface Perfume {
  id: number;
  name: string;
  brand: string;
  price: number;
  image: string;
  rating: number;
  description: string;
  category: string;
  isNew?: boolean;
  isBestseller?: boolean;
}

interface PerfumeCardProps {
  perfume: Perfume;
  isFavorite: boolean;
  onToggleFavorite: (id: number) => void;
}

export const PerfumeCard: React.FC<PerfumeCardProps> = ({ 
  perfume, 
  isFavorite, 
  onToggleFavorite 
}) => {
  return (
    <div className="group bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
      <div className="relative">
        <img 
          src={perfume.image} 
          alt={perfume.name}
          className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 left-4 flex flex-col gap-2">
          {perfume.isNew && (
            <span className="bg-emerald-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
              NOUVO
            </span>
          )}
          {perfume.isBestseller && (
            <span className="bg-rose-500 text-white px-3 py-1 rounded-full text-xs font-semibold">
              PI VANN
            </span>
          )}
        </div>
        <button 
          onClick={() => onToggleFavorite(perfume.id)}
          className={`absolute top-4 right-4 p-2 rounded-full transition-colors ${
            isFavorite 
              ? 'bg-rose-500 text-white' 
              : 'bg-white/80 text-gray-700 hover:bg-rose-500 hover:text-white'
          }`}
        >
          <Heart className="h-5 w-5" />
        </button>
      </div>
      <div className="p-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-rose-600 font-medium">{perfume.category}</span>
          <div className="flex items-center">
            <Star className="h-4 w-4 text-amber-400 fill-current" />
            <span className="text-sm text-gray-600 ml-1">{perfume.rating}</span>
          </div>
        </div>
        <h3 className="font-bold text-gray-900 mb-1">{perfume.name}</h3>
        <p className="text-sm text-gray-600 mb-3">{perfume.brand}</p>
        <p className="text-sm text-gray-500 mb-4">{perfume.description}</p>
        <div className="flex items-center justify-between">
          <span className="text-2xl font-bold text-gray-900">${perfume.price}</span>
          <button className="bg-gradient-to-r from-rose-600 to-rose-700 text-white px-4 py-2 rounded-full text-sm font-semibold hover:from-rose-700 hover:to-rose-800 transition-all transform hover:scale-105">
            Ajoute nan Panye
          </button>
        </div>
      </div>
    </div>
  );
};