import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { PerfumeCard } from './components/PerfumeCard';
import { featuredPerfumes, categories } from './data/perfumes';
import { ChevronRight, Sparkles, Award, Users, Truck } from 'lucide-react';

function App() {
  const [email, setEmail] = useState('');
  const [favorites, setFavorites] = useState<number[]>([]);

  const toggleFavorite = (id: number) => {
    setFavorites(prev => 
      prev.includes(id) 
        ? prev.filter(fav => fav !== id)
        : [...prev, id]
    );
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Mèsi pou abonman ou nan newsletter la!');
    setEmail('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-amber-50">
      <Navigation />
      <HeroSection />

      {/* Featured Products */}
      <section id="products" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Pafen yo ki Pi Renmen</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Dekouvri koleksyon eksklusif pafen prensipal nou yo ki fèt ak sous ki pi kalite yo
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredPerfumes.map((perfume) => (
              <PerfumeCard
                key={perfume.id}
                perfume={perfume}
                isFavorite={favorites.includes(perfume.id)}
                onToggleFavorite={toggleFavorite}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section id="categories" className="py-20 bg-gradient-to-br from-rose-100/50 to-amber-100/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Eksplore pa Kategori</h2>
            <p className="text-gray-600 text-lg max-w-2xl mx-auto">
              Jwenn pafen pèfè a pou chak okazyon ak preferans ou
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {categories.map((category) => (
              <div key={category.name} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-2xl">
                  <img 
                    src={category.image} 
                    alt={category.name}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                  <div className="absolute bottom-6 left-6 text-white">
                    <h3 className="text-2xl font-bold mb-2">{category.name}</h3>
                    <p className="text-rose-200">{category.count} pafen yo</p>
                  </div>
                  <div className="absolute top-6 right-6 bg-white/20 backdrop-blur-sm p-2 rounded-full group-hover:bg-rose-500 transition-colors">
                    <ChevronRight className="h-5 w-5 text-white" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-900 mb-6">Konsènan Nou</h2>
              <p className="text-gray-600 text-lg mb-6 leading-relaxed">
                Depi plis pase 5 ane, nou dedye nan kè ak artisan nan pafen ki pi bon yo nan mond lan. 
                Chak boutèy nou yo se yon chèf-dèv fèt ak sous ki pi bon yo ak teknik tradisyonèl yo.
              </p>
              <p className="text-gray-600 text-lg mb-8 leading-relaxed">
                Nou pòtrè a ak pasyon ak presizyon, nou kreye pafen unik ki konte istwa ak enstè nan chak moun.
              </p>
              
              <div className="grid grid-cols-3 gap-8">
                <div className="text-center">
                  <div className="bg-rose-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Award className="h-8 w-8 text-rose-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">5+</div>
                  <div className="text-sm text-gray-600">Ane ekspèyans</div>
                </div>
                <div className="text-center">
                  <div className="bg-rose-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Users className="h-8 w-8 text-rose-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">100K+</div>
                  <div className="text-sm text-gray-600">Kliyan kontè</div>
                </div>
                <div className="text-center">
                  <div className="bg-rose-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Sparkles className="h-8 w-8 text-rose-600" />
                  </div>
                  <div className="text-2xl font-bold text-gray-900">200+</div>
                  <div className="text-sm text-gray-600">Pafen unik</div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/4465421/pexels-photo-4465421.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Atelier pafen"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl">
                <div className="flex items-center space-x-3">
                  <div className="bg-rose-100 w-12 h-12 rounded-full flex items-center justify-center">
                    <Truck className="h-6 w-6 text-rose-600" />
                  </div>
                  <div>
                    <div className="font-semibold text-gray-900">Livrezon Gratis</div>
                    <div className="text-sm text-gray-600">Sou kòmand $100+</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <Sparkles className="h-8 w-8 text-rose-400" />
                <span className="text-2xl font-bold">Parfum Élite</span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md">
                Depi 2020, nou dedye nan kè ak artisan nan pafen ki pi ekstraòdinè yo nan mond lan.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Lyen Rapid</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#home" className="hover:text-rose-400 transition-colors">Akèy</a></li>
                <li><a href="#products" className="hover:text-rose-400 transition-colors">Pwodwi</a></li>
                <li><a href="#categories" className="hover:text-rose-400 transition-colors">Kategori</a></li>
                <li><a href="#about" className="hover:text-rose-400 transition-colors">Konsènan</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Kontak</h4>
              <ul className="space-y-2 text-gray-400">
                <li>1-800-PARFUM</li>
                <li>info@parfumelite.com</li>
                <li>123 Rue Ste-Philomene</li>
                <li>Cap-Haiten, Haiti</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Parfum Élite. Tout dwa rezève.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;