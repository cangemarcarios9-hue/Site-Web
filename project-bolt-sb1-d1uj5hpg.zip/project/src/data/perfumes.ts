export interface Perfume {
  id: number;
  name: string;
  brand: string;
  price: number;
  image: string;
  rating: number;
  description: string;
  category: string;
  isNew?: boolean;
  isBestseller?: boolean;
}

export const featuredPerfumes: Perfume[] = [
  {
    id: 1,
    name: "Mystique Noir",
    brand: "Élégance",
    price: 145,
    image: "https://images.pexels.com/photos/965989/pexels-photo-965989.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4.8,
    description: "A captivating blend of dark berries and mysterious spices",
    category: "Oriental",
    isNew: true
  },
  {
    id: 2,
    name: "Rose Éternelle",
    brand: "Jardin Secret",
    price: 128,
    image: "https://images.pexels.com/photos/1190829/pexels-photo-1190829.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4.9,
    description: "Timeless rose petals with hints of vanilla and musk",
    category: "Floral",
    isBestseller: true
  },
  {
    id: 3,
    name: "Ocean Breeze",
    brand: "Horizon",
    price: 98,
    image: "https://images.pexels.com/photos/4465124/pexels-photo-4465124.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4.7,
    description: "Fresh aquatic notes with citrus and marine accord",
    category: "Fresh",
  },
  {
    id: 4,
    name: "Golden Amber",
    brand: "Prestige",
    price: 195,
    image: "https://images.pexels.com/photos/1190827/pexels-photo-1190827.jpeg?auto=compress&cs=tinysrgb&w=400",
    rating: 4.9,
    description: "Rich amber with warm woody undertones",
    category: "Woody",
    isBestseller: true
  }
];

export const categories = [
  { name: "Floral", image: "https://images.pexels.com/photos/1666315/pexels-photo-1666315.jpeg?auto=compress&cs=tinysrgb&w=400", count: 24 },
  { name: "Oriental", image: "https://images.pexels.com/photos/4465421/pexels-photo-4465421.jpeg?auto=compress&cs=tinysrgb&w=400", count: 18 },
  { name: "Fresh", image: "https://images.pexels.com/photos/1190796/pexels-photo-1190796.jpeg?auto=compress&cs=tinysrgb&w=400", count: 16 },
  { name: "Woody", image: "https://images.pexels.com/photos/4465370/pexels-photo-4465370.jpeg?auto=compress&cs=tinysrgb&w=400", count: 21 }
];